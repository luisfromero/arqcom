using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;


namespace Master1
{
    public partial class Form1 : Form
    {

    public const int ANCHO = 500;
    public const int ALTO = 500;

        //Curso 2018/19
        bitmapeficiente bitmapEficiente;

    bool conectado = false;
    byte[] finmsg = System.Text.Encoding.ASCII.GetBytes("end");
    System.IO.Stream stm;
    byte[] datos = new byte[ANCHO * ALTO];
    Color[] mapacolores;
    

        void terminarA()
        {
            //Cliente.Send(finmsg);
            //Cliente.Disconnect(true);
            stm.Write(finmsg, 0, finmsg.Length);
            tcpclnt.Close();
        }
        void status()
        {
            //textBox2.Visible = !conectado;
            textBox1.Visible = conectado;
            button1.Visible = conectado;
            if (conectado) button2.Text = "Desconectar";
            else button2.Text = "Conectar";
            timer1.Interval = 10;
            timer1.Enabled = conectado;
        }
        public Form1()
        {
            InitializeComponent();
            status();
            pictureBox1.Width=ANCHO;
            pictureBox1.Height=ALTO;
            ClientSize = new Size(ANCHO, 70 + ALTO);
            //pictureBox1.Image = new Bitmap(ANCHO, ALTO);
            //2018/19
            bitmapEficiente = new bitmapeficiente(500, 500);
            pictureBox1.Image = bitmapEficiente.Bitmap;
            mapacolores = (Color[]) bitmapeficiente.JET.Clone();
            }
        

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                byte[] data = System.Text.Encoding.ASCII.GetBytes(textBox1.Text);
                //Cliente.Send(data);
                stm.Write(data, 0, data.Length);
            }
            catch (SocketException se){Close();}
            if (textBox1.Text == "end")
                //cliente.Disconnect(true);
                tcpclnt.Close();
            //conectado = Cliente.Connected;
            conectado = tcpclnt.Connected;
            status();
        }

        TcpClient tcpclnt;
        private void button2_Click(object sender, EventArgs e)
        {
            if (!conectado)
                try
                {
                    //Cliente = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    //IPEndPoint remoteEP = new IPEndPoint(IPAddress.Parse(textBox2.Text), (int)numericUpDown1.Value);
                    //Cliente.Connect(remoteEP);
                    IPAddress[] ips;
                    //IPAddress ips2;
                    ips = Dns.GetHostAddresses(textBox2.Text);
                    //ips2=IPAddress.Parse(textBox2.Text);


                    tcpclnt = new TcpClient();
                    tcpclnt.Connect(ips[0], (int)numericUpDown1.Value);
                    stm = tcpclnt.GetStream();
                }
                catch {}
                finally
                {
                    //conectado = Cliente.Connected;
                    conectado = tcpclnt.Connected;
                }
            else
                try
                {
                    terminarA();
                }
                catch { }
                finally
                {
                    //conectado = Cliente.Connected;
                    conectado = tcpclnt.Connected;
                }
            status();
        }

        //Finaliza. Si es preciso, env�a informaci�n al servidor.

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            if(conectado)terminarA();
            bitmapEficiente.Dispose();
        }




        //Actualiza la imagen con los datos. Se hace con cada timer-tick

        private void dibuja(byte[] datos)
        {

            for (int i=0;i<ALTO;i++)
                for (int j = 0; j < ANCHO; j++)
                {
                    //COLOR c = jet(datos[i * 500 + j]);
                    ((Bitmap)pictureBox1.Image).SetPixel(j, i, mapacolores[datos[i * 500 + j]]);
                }
        }
        private void dibujaEficiente(byte[] datos)
        {
            for (int i = 0; i < ALTO; i++)
                for (int j = 0; j < ANCHO; j++)
                {
                    bitmapEficiente.SetPixel(j, i, mapacolores[datos[i * 500 + j]]);
                }
            //pictureBox1.Image = bitmapEficiente.Bitmap;
        }


        //Peri�dicamente (cada 10 milisegundos), espera la llegada de un paquete con ANCHO*ALTO bytes


        private void timer1_Tick(object sender, EventArgs e)
        {
            tcpclnt.ReceiveTimeout = 50;
            try
            {
                int k;
                int recibidos=0;
                do{
                    k = stm.Read(datos, recibidos, ANCHO * ALTO - recibidos); recibidos += k;
                } while (recibidos < ANCHO * ALTO);
                dibujaEficiente(datos);
                pictureBox1.Refresh();
            }
            catch (Exception se) {
                //Timeout (no recibe nada)
                //Close();
                return;
            }
        }

        // Env�a un mensaje al servidor, con el car�cter $ en la posici�n 0 
        // para identificar el env�o de coordenadas.

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            int tempe = (int)trackBar1.Value;
            //string a = "$" + e.X.ToString("000") + e.Y.ToString("000")+"255";
            string a = "$" + e.X.ToString("000") + e.Y.ToString("000") + tempe.ToString("000");
            try
            {
                byte[] data = System.Text.Encoding.ASCII.GetBytes(a);
                if(conectado)stm.Write(data, 0, data.Length);
            }
            catch (SocketException se) { Close(); }
        }


    }
}