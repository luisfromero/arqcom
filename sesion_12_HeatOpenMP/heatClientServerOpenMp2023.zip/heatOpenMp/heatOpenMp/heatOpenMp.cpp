/*
* File:   main.c
* Author: felipe
*
* Created on 1 de diciembre de 2015, 13:27
* Modificado el 29 de noviembre de 2023
*
* Servidor Heat. Se inicia en modo de espera de un cliente
*
* Cuando se establece la conexion, crea un thread que espera la llegada de comandos.
* El hilo principal envia paquetes de SIZE bytes, con los resultados del servicio
* El servicio ejecuta un paso del m�todo explicito de resolucion por diferencias finitas
* de la eq de calor con un coeficiente de difusion arbitrario.
*/

#ifdef _WIN32

#define bzero(a, b) memset(a, 0x0, b)
#include "targetver.h"
#include <tchar.h>
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <WinSock2.h>
#include <ws2tcpip.h>
#include <Windows.h>
#pragma comment(lib, "Ws2_32.lib")
#define HAVE_STRUCT_TIMESPEC
#include "pthread.h" 
#else
#include <pthread.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <omp.h>
#include <chrono>


#define SIZEX 500
#define SIZEY 500
#define MAXITER 500
#define SIZE SIZEX*SIZEY

// verbose:	Muestra mensajes
// timing: 	Mide tiempos
// standalone: 	Simula, pero no se comunica con la m�quina externa

int  verbose = 0;
int  timing = 1;
bool  conEnvios = true; //Solo si se va a medir tiempo de simulac sin envio de datos

#ifdef _WIN32
WSADATA wsaData;
#else
#define SOCKET int
#endif


//Variable global, compartida, con la temperatura 
double w[SIZEY][SIZEX];
//Variable global, privada, con la temperatura 
double u[SIZEY][SIZEX];

char mess[100] = "";
bool finalizando = false;
bool finalizado = false;
char image[SIZE];
int nt, id;
int cnt;
int lim_inf, lim_sup;

// Variables globales (visible en todas las rutinas), pero de uso privatizado
#pragma omp threadprivate(id,lim_inf,lim_sup,u)



//Establece una condicion de contorno Dirichlet
//          Helado
//Templado              Calor
//          Frio


int iniheat()
{
	int i, j;
	double mean;
	for (i = 1; i < SIZEY - 1; i++)
	{
		w[i][0] = 200.0;
	}
	for (i = 1; i < SIZEY - 1; i++)
	{
		w[i][SIZEX - 1] = 255.0;
	}
	for (j = 0; j < SIZEX; j++)
	{
		w[SIZEY - 1][j] = 100.0;
	}
	for (j = 0; j < SIZEX; j++)
	{
		w[0][j] = 0.0;
	}
	/*
	Calcula un valor interpolado en la zona interior
	*/
	mean = 0.0;
	for (i = 1; i < SIZEY - 1; i++)
	{
		mean = mean + w[i][0];
	}
	for (i = 1; i < SIZEY - 1; i++)
	{
		mean = mean + w[i][SIZEX - 1];
	}
	for (j = 0; j < SIZEX; j++)
	{
		mean = mean + w[SIZEY - 1][j];
	}
	for (j = 0; j < SIZEX; j++)
	{
		mean = mean + w[0][j];
	}
	mean = mean / (double)(2 * SIZEY + 2 * SIZEX - 4);
	/*
	Initialize the interior solution to the mean value.
	*/
	for (i = 1; i < SIZEY - 1; i++)
	{
		for (j = 1; j < SIZEX - 1; j++)
		{
			w[i][j] = mean;
		}
	}
	return 0;
}




#ifdef _WIN32
	// Initialize Winsock
SOCKET open_socket(int  puerto) {
	int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("WSAStartup failed: %d\n", iResult);
		return 1;
	}
	struct addrinfo *result = NULL, *ptr = NULL, hints;
	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;
	hints.ai_flags = AI_PASSIVE;
	char buffer[33];
	itoa(puerto, buffer, 10);
	// Resolve the local address and port to be used by the server
	iResult = getaddrinfo(NULL, buffer, &hints, &result);
	if (iResult != 0) {
		printf("getaddrinfo failed: %d\n", iResult);
		WSACleanup();
		return 1;
	}
	SOCKET ListenSocket = INVALID_SOCKET;
	ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
	if (ListenSocket == INVALID_SOCKET) {
		printf("Error at socket(): %ld\n", WSAGetLastError());
		freeaddrinfo(result);
		WSACleanup();
		return 1;
	}
	// Setup the TCP listening socket
	iResult = bind(ListenSocket, result->ai_addr, (int)result->ai_addrlen);
	if (iResult == SOCKET_ERROR) {
		printf("bind failed with error: %d\n", WSAGetLastError());
		freeaddrinfo(result);
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}
	freeaddrinfo(result);
	if (listen(ListenSocket, SOMAXCONN) == SOCKET_ERROR) {
		printf("Listen failed with error: %ld\n", WSAGetLastError());
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}
	SOCKET ClientSocket = INVALID_SOCKET;
	struct sockaddr cli_addr;
	// Accept a client socket
	int i = sizeof(cli_addr);
	ClientSocket = accept(ListenSocket, &cli_addr, &i);
	if (ClientSocket == INVALID_SOCKET) {
		printf("accept failed: %d\n", WSAGetLastError());
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}
	return ClientSocket;
}
#else
SOCKET open_socket(int  puerto) {
	int on = 1;
	int sockfd;
	int  portno, clilen;
	char buffer[256], test;
	struct sockaddr_in serv_addr, cli_addr;
	int n;
	int sockid = socket(AF_INET, SOCK_STREAM, 0);
	if (sockid < 0) 
		printf("ERROR opening socket\n");
	bzero((char *)&serv_addr, sizeof(serv_addr));
	portno = (int)puerto;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(portno);
	setsockopt(sockid, SOL_SOCKET, SO_REUSEADDR, (const char *) &on, sizeof(on));
	if (bind(sockid, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
	{
		printf("ERROR binding\n");
		exit(0);
	}
	listen(sockid, 5);
	clilen = sizeof(cli_addr);
	sockfd = accept(sockid, (struct sockaddr *) &cli_addr, &clilen);
	if (sockfd < 0) {
		printf("ERROR aceptando\n");
		exit(0);
	}

	return sockfd;
}
#endif
int heat()
{
	int i;
	int j;
	int limi, lims; //(l�mites reales, ambos incluidos)

	//Copiamos a u (privada), los datos de w (compartida), con halo
	// 
	//Ejemplo 500 filas, 5 threads:
	//Thread 0: lim_inf=  0, lim_sup= 99 (incl), limi=  0, lims=100
	//Thread 1: lim_inf=100, lim_sup=199 (incl), limi= 99, lims=200 
	//Thread 2: lim_inf=200, lim_sup=299 (incl), limi=199, lims=300 
	//Thread 3: lim_inf=300, lim_sup=399 (incl), limi=299, lims=400 
	//Thread 4: lim_inf=400, lim_sup=499 (incl), limi=399, lims=499 

	limi = (id == 0) ? 0 : lim_inf - 1;
	lims = (id == nt - 1) ? SIZEY-1 : lim_sup+ 1;
	for (i = limi; i < lims; i++)
	{
		for (j = 0; j < SIZEX; j++)
		{
			u[i][j] = w[i][j];
		}
	}

	// Ahora avanzamos w(n+1) = f(u(n))
	// Las filas 0 y 499 no se simulan (Dirichlet)
	limi = (id == 0) ? 1 : lim_inf;
	lims = (id == nt - 1) ? SIZEY - 2 : lim_sup;

	if (cnt == 0)printf("%d %d %d %d\n", id, cnt, limi, lims);
	for (i = limi; i <= lims; i++)
	{
		for (j = 1; j < SIZEX - 1; j++)
		{
			w[i][j] = (u[i - 1][j] + u[i + 1][j] + u[i][j - 1] + u[i][j + 1]) / 4.0;
		}
	}
//#pragma omp barrier
	return 0;
}

/**
* Establece la temperatura t en un punto x,y y sus alrededores
*/
void calentar(int x, int y, int t)
{
	int size = 5;
	int i, j;
	for (i = y - size; i <= y + size; i++)
		for (j = x - size; j <= x + size; j++)
		{
			if ((i>-1) && (i<SIZEY) && (j>-1) && (j<SIZEX))
				w[i][j] = t;
		}

}

/**
* Copia la temperatura w de la superficie (double) a un array de bytes
*/
void copyimage()
{
	int i, j;
	for (i = 0; i<SIZEY; i++)
		for (j = 0; j<SIZEX; j++)
			image[i*SIZEX + j] = (char)w[i][j];

}

int coordX, coordY, tempe;

/**
* Hilo que recibe mensajes de temperatura de forma as�ncrona
*/
void *funcion_hilo(void * psock_id) {
	int n = 0;
	SOCKET sock_id = *(SOCKET *)psock_id; //recuperamos par�metro a partir de puntero
	if (conEnvios)
		do {
			//sleep(1);
			bzero(mess, 100);
			n = recv(sock_id, mess, 100,0);
			printf("\nEl thread ha recibido  %d bytes (%s)\n", n, mess);
			if (n < 0) perror("ERROR leyendo del socket");
			if (n>9)if (mess[0] == '$') {
				sscanf(mess, "$%03d%03d%03d", &coordX, &coordY, &tempe);

				if (verbose)printf("Recibidos %d y %d \n", coordX, coordY);
				//image[SIZEX*coordY+coordX]=128;
				//w[coordY][coordX]=250;
				calentar(coordX, coordY, tempe);
			}

		} while (strcmp(mess, "end"));
		printf("\nThread receptor de mensajes terminando...\n");
		//pthread_exit(NULL);
		return 0;
}

pthread_t mithread; /* thread and attributes */
SOCKET sock_id;

void terminarThreadSocket()
{
	if (conEnvios) {
		if (verbose)printf("Esperando el fin del thread de comunicaci�n...\n");
#ifdef _WIN32
#else
#endif 
		pthread_join(mithread, NULL);
		if (verbose)printf("Cerrando el socket...\n");

#ifdef _WIN32
		closesocket(sock_id);
		WSACleanup();
#else
		close(sock_id);
#endif 

	}
}



ULONG64 diferencia(
	std::chrono::high_resolution_clock::time_point a, 
	std::chrono::high_resolution_clock::time_point b) {
	return (std::chrono::duration_cast<std::chrono::nanoseconds>((b - a)).count());
}
void muestraTiempos(ULONG64 tiempoAB, ULONG64 tiempoBC, ULONG64 tiempoCD,int ciclos) {
	if (!timing)return;
#pragma omp barrier

#pragma omp for ordered
	for (int i = 0; i < nt; ++i) {
#pragma omp ordered
		{
			printf("Thread %d: Tiempo wait: %8.5f en %d ciclos\n", id, tiempoAB / 1e9, ciclos);
		}
	}

#pragma omp single
		{
			printf("\n");
		}
#pragma omp barrier

#pragma omp for ordered
	for (int i = 0; i < nt; ++i) {
#pragma omp ordered
			{
			printf("Thread %d: Tiempo heat: %8.5f en %d ciclos\n", id, tiempoBC / 1e9, ciclos);
			}
		}

#pragma omp single
		{
			printf("\n");
		}

	// Ejemplo printf desordenado
	printf("Thread %d: Tiempo send: %8.5f en %d ciclos\n", id, tiempoCD / 1e9, ciclos);

}


int main(int argc, char** argv) {
	int puerto;
	nt = 5;
	omp_set_num_threads(nt);
	sock_id = 0;
	if (conEnvios) {
		if (argc < 2) {
			printf("Modo de empleo: servidor port\n");
			exit(0);
		}
		puerto = atoi(argv[1]);
		printf("Abriendo puerto %d en espera de un cliente...\n", puerto);
		int puerto = atoi(argv[1]);
		sock_id = open_socket(puerto);
		printf("Slave conectado.........\n");
		pthread_create(&mithread, NULL, funcion_hilo, (SOCKET*)&sock_id);
		printf("Thread iniciado \n");
	}
	iniheat();
	//--------------------------------------------------------------------------------------------------------
	//--------------------------------------------------------------------------------------------------------
#pragma omp parallel 
	{
		cnt = 0;
		id = omp_get_thread_num();
#pragma omp barrier
		lim_inf = (SIZEY / nt) * id;
		lim_sup = (SIZEY / nt) * (id + 1) - 1;


		if (verbose)printf("Soy %d de %d, y calculo desde %d hasta %d \n", id, nt, lim_inf, lim_sup);

		//Puntos de medida de reloj de pared (ticks) para medir tiempos
		std::chrono::high_resolution_clock::time_point a, b, c, d;

		//Diferencias de tiempos entre dos ticks (en nanosegundos)
		ULONG64 tiempoAB = 0,tiempoBC = 0,tiempoCD = 0;


		//Ciclos de vida (privados para cada thread)
		int ciclos = 0;
		do {
			a = std::chrono::high_resolution_clock::now();
			ciclos++;

			//Descomentar para s�ncronos
			//#pragma omp barrier
			b = std::chrono::high_resolution_clock::now();
			heat();
			c = std::chrono::high_resolution_clock::now();
			if (id == 0) {
				finalizando = !strcmp(mess, "end");
				if (conEnvios && !finalizando) // Si no ha terminado
				{
					copyimage();
					send(sock_id, image, SIZE, 0);
				}
				cnt++;
			}

			d = std::chrono::high_resolution_clock::now();
			tiempoAB += diferencia(a,b);
			tiempoBC += diferencia(b,c);
			tiempoCD += diferencia(c,d);


		} while (!finalizando);

		muestraTiempos(tiempoAB, tiempoBC, tiempoCD, ciclos);

	} //end parallel section


	terminarThreadSocket();

	//--------------------------------------------------------------------------------------------------------
	//--------------------------------------------------------------------------------------------------------
}


