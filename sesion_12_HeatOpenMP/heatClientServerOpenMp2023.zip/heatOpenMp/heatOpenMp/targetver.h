#pragma once

// La inclusi�n de SDKDDKVer.h define la plataforma Windows m�s alta disponible.

// Si desea compilar la aplicaci�n para una plataforma Windows anterior, incluya WinSDKVer.h y
// establezca la macro _WIN32_WINNT en la plataforma que desea admitir antes de incluir SDKDDKVer.h.

#include <SDKDDKVer.h>
